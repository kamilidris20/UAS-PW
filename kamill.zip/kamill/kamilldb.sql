-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 26 Okt 2024 pada 22.34
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kamilldb`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `quote` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `about`
--

INSERT INTO `about` (`id`, `title`, `description`, `quote`, `image_url`) VALUES
(1, 'About Me', '', NULL, NULL),
(5, '', 'Hello! My name is Muhammad Kamil Idris, and I am a fifth-semester Informatics student at Universitas Pembangunan Jaya. My passion for technology drives me to explore various aspects of computer science, including web development and user experience design.\r\n\r\nThroughout my studies, I have participated in projects that blend theory with practical applications, allowing me to develop my skills and understanding of the field. I am also involved in student organizations, where I collaborate with peers to tackle challenges and share innovative ideas.\r\n\r\nAs I continue my academic journey, I aim to specialize in software development and data analysis, with a focus on how technology can positively impact society. Thank you for visiting my website, and I hope you enjoy exploring my work!', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `experience`
--

CREATE TABLE `experience` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `quote` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `experience`
--

INSERT INTO `experience` (`id`, `title`, `description`, `quote`, `start_date`, `end_date`, `company`, `image_url`) VALUES
(6, '1', 'Wedding Photographer', 'As a wedding photographer, I was responsible for documenting the special moments of couples on their big day. I honed my skills in capturing candid shots and arranging poses to ensure that each photo looked natural and emotional. This role taught me how to communicate effectively with clients to understand their expectations and desires.', NULL, NULL, NULL, NULL),
(7, '2', 'Model Photographer', 'In my role as a model photographer, I collaborated with various models to create visually compelling images. This experience helped me understand the important aspects of lighting, composition, and pose direction, as well as how to capture the essence of each model\'s personality in every shot.\r\n\r\n', NULL, NULL, NULL, NULL),
(8, '3', 'Wedding Photo Editor', 'As a wedding photo editor, I utilized editing software to enhance image quality, correct colors, and create an atmosphere that aligned with the event\'s theme. I learned to balance technical editing skills with creative vision to produce photos that were not only beautiful but also meaningful to the couples.', NULL, NULL, NULL, NULL),
(9, '4', 'Futsal Competitor\r\n', 'During my time in middle school, I participated in a futsal tournament at the district level and achieved second place. This experience taught me the importance of teamwork, discipline, and strategy in sports. I learned to adapt to various situations on the field and improve my physical skills.', NULL, NULL, NULL, NULL),
(10, '5', 'Tennis Club Competitor\r\n\r\n\r\n', 'I also competed in a tennis tournament among clubs and secured second place. In this experience, I enhanced my technical tennis skills and developed a competitive mindset. I understood the significance of preparation and practice in achieving positive results in competitions.', NULL, NULL, NULL, NULL),
(11, 'Experience', '', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `home`
--

CREATE TABLE `home` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `quote` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `home`
--

INSERT INTO `home` (`id`, `title`, `description`, `quote`, `image_url`) VALUES
(1, 'Muhammad Kamil', 'I\'m ', NULL, NULL),
(2, 'Designer', 'Developer', 'Photographer', NULL),
(3, 'Hi Guyss! I\'m', '', NULL, NULL),
(4, '', '\"Hi there, and welcome! Thanks for stopping by feel free to explore my work and journey here!\"', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `quote` text DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `project`
--

INSERT INTO `project` (`id`, `title`, `description`, `quote`, `link`, `image_url`) VALUES
(1, 'My Project', '', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `home`
--
ALTER TABLE `home`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
